import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Akinator {
    private static WebDriver driver;

    public static void main(String[] args) {
        initiateGame();
        answerQuestions();
        confirmYourHero();
    }

    private static void clickCss(String selector) {
        driver.findElement(By.cssSelector(selector)).click();
    }
    private static String getTextByCss(String selector) {
        return driver.findElement(By.cssSelector(selector)).getText();
    }

    private static void wait(int time) {
        try {
            TimeUnit.SECONDS.sleep(time);
        } catch (Exception e) {}
    }

    private static void initiateGame() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver");

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://ru.akinator.com");
        clickCss("a[href='/game']");
    }

    private static void endGame() {
        driver.quit();
    }

    private static void showFiveOptions() {
        System.out.println("Варианты ответа:");

        System.out.println(getTextByCss("a[id='a_yes']") + " - 1");
        System.out.println(getTextByCss("a[id='a_no']") + " - 2");
        System.out.println(getTextByCss("a[id='a_dont_know']") + " - 3");
        System.out.println(getTextByCss("a[id='a_probably']") + " - 4");
        System.out.println(getTextByCss("a[id='a_probaly_not']") + " - 5");

        try {
            System.out.println(getTextByCss("span[class='back-button-text']") + " - 6");
        } catch (Exception e){
            System.out.print("");
        }
    }

    private static int showTwoOptions() {
        System.out.println("--------------------");
        System.out.println("| Да - 1 | Нет - 2 |");
        System.out.println("--------------------");

        Scanner scanner = new Scanner(System.in);
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                return 1;
            case 2:
                return 2;
            default:
                System.out.println("Этого варианта не существует. Попробуйте еще раз. Спасибо!");
                showTwoOptions();
        }
        return 0;
    }

    private static void answerQuestions() {
        wait(5);
        while (isQuestionPresent()) {
            String question = driver.findElement(By.xpath("//p[@class='question-text']")).getText();
            String number = driver.findElement(By.xpath("//p[@class='question-number']")).getText();

            System.out.println(number + ". " + question);

            showFiveOptions();
            chooseYourOption();
            wait(5);

        }
    }

    private static boolean isQuestionPresent() {
        try {
            driver.findElement(By.xpath("//p[@class='question-text']"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void chooseYourOption() {
        Scanner scanner = new Scanner(System.in);
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                clickCss("a[id='a_yes']");
                break;
            case 2:
                clickCss("a[id='a_no']");
                break;
            case 3:
                clickCss("a[id='a_dont_know']");
                break;
            case 4:
                clickCss("a[id='a_probably']");
                break;
            case 5:
                clickCss("a[id='a_probaly_not']");
                break;
            case 6:
                clickCss("a[id='a_cancel_answer']");
                break;
            default:
                System.out.println("Этого варианта не существует. Попробуйте еще раз. Спасибо!");
                chooseYourOption();
        }
    }

    private static void confirmYourHero() {
        if (!driver.findElement(By.xpath("//span[@class='proposal-title']")).isEnabled()) {
            System.out.println("Извините произошла ошибка. Попробуйте еще раз!");
            return;
        } else {
            String answer = driver.findElement(By.xpath("//span[@class='proposal-title']")).getText() + " (" +
                    driver.findElement(By.xpath("//span[@class='proposal-subtitle']")).getText() + ")";

            System.out.println("Я думаю это: " + answer);
        }

        confirmProposal();
    }

    private static void confirmProposal() {
        if (showTwoOptions() == 1) {
            clickCss("a[id='a_propose_yes']");
            System.out.println(driver.findElement(By.xpath("//div[@class='bubble-standard bubble-win bubble']")).getText());
            endGame();
        } else {
            clickCss("a[id='a_propose_no']");
            continueGame();
        }
    }

    private static void continueGame() {
        System.out.println(driver.findElement(By.xpath("//span[@class='proposal-title']")).getText());
        if (showTwoOptions() == 1) {
            clickCss("a[id='a_continue_yes']");
            answerQuestions();
            confirmYourHero();
        } else {
            clickCss("a[id='a_continue_no']");
            enterYourHero();
        }
    }

    private static void enterYourHero() {

        soundLike3();
        soundLike2();

        wait(5);
        System.out.println(driver.findElement(By.xpath("//span[@class='win-sentence']")).getText());
        endGame();

    }

    private static void soundLike3() {
        wait(5);

        try {
            driver.findElement(By.xpath("//input[@id='not_in_list']")).click();
            wait(5);
        } catch (Exception e) {
        }

        System.out.println(getTextByCss("div[class='col-md-12 page-formulaire soundlike3']"));

        Scanner scanner = new Scanner(System.in);
        String value = scanner.nextLine();

        driver.findElement(By.cssSelector("input[name='name']")).sendKeys(value + Keys.ENTER);
    }

    private static void soundLike2() {
        wait(5);

        try {
            driver.findElement(By.xpath("//input[@id='show_add_perso']")).click();
            wait(5);
        } catch (Exception e) {
        }

        System.out.println(getTextByCss("div[class='col-md-12 page-formulaire aki-formulaire soundlike2']"));

        System.out.println("Имя:");

        Scanner scanner = new Scanner(System.in);
        String value = scanner.nextLine();

        driver.findElement(By.cssSelector("input[name='name']")).sendKeys(value);

        System.out.println("Описание:");
        String desc = scanner.nextLine();
        scanner.close();
        driver.findElement(By.cssSelector("input[name='desc']")).sendKeys(desc);

        clickCss("input[id='add_perso']");
    }
}
